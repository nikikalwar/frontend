/* All men are mortal 
    Socrates is a man
    Therefore,socrates is mortal. */

  //understanding Syllogism
  //categorical Syllogism

  //if A is part of C, then B is part of C" logic

const mortal="men";
const socrates="man";

if(socrates==="man" && mortal==="men"){
    console.log("Therefore,socrates is mortal");
}


   
    
