//homework assignment

var genre="Jazz";
var artist="Niki";
var year="2020";
var durationInSeconds=328;
var country="Nepal";
var popularity="high";

console.log(artist);//artist name
console.log(genre);//song genre
console.log(durationInSeconds);//durationInSeconds
console.log(year);//year the song was published
console.log(country);//country the song was published 
console.log(popularity);//popularity of the song




