//todo list

//gathering requirements for the list
/*index

fresh reload-->user should see sign up and log in



/*dashboard

1.the to-do lists should list in chronological order
//chronological means --by the order the occur //time

2.If one of the lists is clicked on, the user should be taken to that list

3.If a user clicks to create a new to do list/-->taken to the blank list

*/

/*

list specification 
1.Name/rename the list//as long as it doesn't match with other item in the list
2.add as many items to that list as they wish
3.check /uncheck any list
4.application should support as many unique users as possibly


*/

/*
extra specs:
hashing algorithm
*/

/*






